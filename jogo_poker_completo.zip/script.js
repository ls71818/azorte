
function playerAction(action) {
  const amount = document.getElementById('bet-amount').value || 0;
  document.querySelector('#player-user .action').innerText = action.toUpperCase() + (amount ? ' $' + amount : '');
  simulateBots();
  checkWinner();
}

function simulateBots() {
  for (let i = 1; i <= 5; i++) {
    const actions = ['CALL', 'RAISE', 'FOLD', 'ALL-IN'];
    const action = actions[Math.floor(Math.random() * actions.length)];
    document.querySelector(`#player-bot${i} .action`).innerText = action;
  }
}

function checkWinner() {
  const hands = ['Pair', 'Two Pair', 'Three of a Kind', 'Straight', 'Flush', 'Full House', 'Quads', 'Straight Flush', 'Royal Flush'];
  const winner = `Bot ${Math.ceil(Math.random() * 5)} ganhou com ${hands[Math.floor(Math.random() * hands.length)]}!`;
  document.getElementById('popup').innerText = winner;
}
